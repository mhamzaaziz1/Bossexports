<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<?php $this->load->view('admin/reports/top_buyers_per_item'); ?>
<?php init_tail(); ?>