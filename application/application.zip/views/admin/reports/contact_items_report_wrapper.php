<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<?php $this->load->view('admin/reports/contact_items_report'); ?>
<?php init_tail(); ?>