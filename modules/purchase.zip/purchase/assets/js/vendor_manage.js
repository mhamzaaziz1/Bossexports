(function($) {
"use strict";  
	initDataTable('.table-vendors', admin_url+'purchase/table_vendor');
})(jQuery);