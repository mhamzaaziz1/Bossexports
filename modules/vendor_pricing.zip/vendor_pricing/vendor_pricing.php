<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
Module Name: Vendor PO Pricing
Description: Standalone module to allow vendors to input their prices directly on Purchase Orders.
Version: 1.0.0
Requires at least: 2.3.*
*/

define('VENDOR_PRICING_MODULE_NAME', 'vendor_pricing');

hooks()->add_action('admin_init', 'vendor_pricing_permissions');
hooks()->add_action('admin_init', 'vendor_pricing_module_init_menu_items');

/**
* Register activation module hook
*/
register_activation_hook(VENDOR_PRICING_MODULE_NAME, 'vendor_pricing_module_activation_hook');

function vendor_pricing_module_activation_hook()
{
    $CI = &get_instance();
    require_once(__DIR__ . '/install.php');
}

/**
* Register language files, must be registered if the module is using languages
*/
register_language_files(VENDOR_PRICING_MODULE_NAME, [VENDOR_PRICING_MODULE_NAME]);

/**
 * Init vendor_pricing module menu items in setup in admin_init hook
 * @return null
 */
function vendor_pricing_module_init_menu_items()
{
    $CI = &get_instance();

    if (has_permission('vendor_pricing', '', 'view')) {
        $CI->app_menu->add_sidebar_menu_item('vendor_pricing', [
            'name'     => _l('vendor_pricing'), // The name if the item to display
            'href'     => admin_url('vendor_pricing'), // URL of the item
            'position' => 31, // The menu position
            'icon'     => 'fa fa-money', // Font awesome icon
        ]);
    }
}

function vendor_pricing_permissions()
{
    $capabilities = [];

    $capabilities['capabilities'] = [
            'view'   => _l('permission_view') . '(' . _l('permission_global') . ')',
            'create' => _l('permission_create'),
            'edit'   => _l('permission_edit'),
            'delete' => _l('permission_delete'),
    ];

    register_staff_capabilities('vendor_pricing', $capabilities, _l('vendor_pricing'));
}
